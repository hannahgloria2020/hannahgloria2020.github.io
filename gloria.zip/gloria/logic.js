var asjsconfig = {
    asjs1: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs2: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs3: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs4: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs5: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs6: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs7: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs8: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs9: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs10: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs11: { hover: "India", url: window.location.href + "/india", target: "same_window", upColor: "#CF8057", overColor: "grey", downColor: "#CF8057", active: !0 },
    asjs12: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs13: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs14: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs15: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs16: { hover: "Japan", url: window.location.href + "/japan", target: "same_window", upColor: "#CF8057", overColor: "grey", downColor: "#CF8057", active: !0 },
    asjs17: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs18: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs19: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs20: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs21: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs22: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs23: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs24: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs25: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs26: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs27: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs28: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs29: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs30: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs31: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs32: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs33: { hover: "Filipijnen", url: window.location.href + "/filipijnen", target: "same_window", upColor: "#CF8057", overColor: "grey", downColor: "#CF8057", active: !0 },
    asjs34: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs35: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs36: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs37: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs38: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs39: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs40: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs41: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs42: { hover: "Thailand", url: window.location.href + "/thailand", target: "same_window", upColor: "#CF8057", overColor: "grey", downColor: "#CF8057", active: !0 },
    asjs43: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs44: { hover: "Turkije", url: window.location.href + "/turkije", target: "same_window", upColor: "#CF8057", overColor: "grey", downColor: "#CF8057", active: !0 },
    asjs45: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs46: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs47: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs48: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    asjs49: { hover: "", url: window.location.href, target: "same_window", upColor: "#ffe681", overColor: "#ffe681", downColor: "#ffe681", active: !0 },
    general: { borderColor: "#9CA8B6", visibleNames: "black" },
};  
function isTouchEnabled() {
    return "ontouchstart" in window || navigator.MaxTouchPoints > 0 || navigator.msMaxTouchPoints > 0;
}
jQuery(function () {
    jQuery("path[id^=asjs]").each(function (i, e) {
        asaddEvent(jQuery(e).attr("id"));
    });
});
function asaddEvent(id, relationId) {
    var _obj = jQuery("#" + id);
    var arr = id.split("");
    var _Textobj = jQuery("#" + id + "," + "#asjsvn" + arr.slice(4).join(""));
    jQuery("#" + ["visnames"]).attr({ fill: asjsconfig.general.visibleNames });
    _obj.attr({ fill: asjsconfig[id].upColor, stroke: asjsconfig.general.borderColor });
    _Textobj.attr({ cursor: "default" });
    if (asjsconfig[id].active === !0) {
        _Textobj.attr({ cursor: "pointer" });
        _Textobj.hover(
            function () {
                jQuery("#jstip").show().html(asjsconfig[id].hover);
                _obj.css({ fill: asjsconfig[id].overColor });
            },
            function () {
                jQuery("#jstip").hide();
                jQuery("#" + id).css({ fill: asjsconfig[id].upColor });
            }
        );
        if (asjsconfig[id].target !== "none") {
            _Textobj.mousedown(function () {
                jQuery("#" + id).css({ fill: asjsconfig[id].downColor });
            });
        }
        _Textobj.mouseup(function () {
            jQuery("#" + id).css({ fill: asjsconfig[id].overColor });
            if (asjsconfig[id].target === "new_window") {
                window.open(asjsconfig[id].url);
            } else if (asjsconfig[id].target === "same_window") {
                window.parent.location.href = asjsconfig[id].url;
            } else if (asjsconfig[id].target === "modal") {
                jQuery(asjsconfig[id].url).modal("show");
            }
        });
        _Textobj.mousemove(function (e) {
            var x = e.pageX + 10,
                y = e.pageY + 15;
            var tipw = jQuery("#jstip").outerWidth(),
                tiph = jQuery("#jstip").outerHeight(),
                x = x + tipw > jQuery(document).scrollLeft() + jQuery(window).width() ? x - tipw - 20 * 2 : x;
            y = y + tiph > jQuery(document).scrollTop() + jQuery(window).height() ? jQuery(document).scrollTop() + jQuery(window).height() - tiph - 10 : y;
            jQuery("#jstip").css({ left: x, top: y });
        });
    }
}
